﻿// See https://aka.ms/new-console-template for more information



using observerpattern;

EarthQuakeMeasurement publisherObj = new EarthQuakeMeasurement();
publisherObj.Register(new AajTakNews("AAJ TAK"));
publisherObj.Register(new ZeeNews("ZEE NEWS"));
publisherObj.SeismoMagnitude = 7.1m;




