﻿namespace observerpattern
{
    public interface ISubject
    {
        void Register(IObserver observer);
        void UnRegister(IObserver observer);
        void Notify();
    }

    public interface IObserver
    {
        void Update(ISubject subject);
    }

    public class ZeeNews : IObserver
    {
        private readonly string _newsChannelName;

        public ZeeNews(string newsChannelName)
        {
            _newsChannelName = newsChannelName;
        }
        public void Update(ISubject subject)
        {
            if (subject is EarthQuakeMeasurement earthQuakeMeasurement)
            {
                Console.WriteLine($"Breakihng news from {_newsChannelName} :: Danger of EarthQuake, seismo records {earthQuakeMeasurement.SeismoMagnitude} , be safe.");
            }
        }
    }

    public class AajTakNews : IObserver
    {
        private readonly string _newsChannelName;

        public AajTakNews(string newsChannelName)
        {
            _newsChannelName = newsChannelName;
        }

        public void Update(ISubject subject)
        {
            if(subject is EarthQuakeMeasurement earthQuakeMeasurement)
            {
                Console.WriteLine($"Big bulletin news from {_newsChannelName} :: Danger of EarthQuake , seismo records {earthQuakeMeasurement.SeismoMagnitude} , be safe.");
            }
        }
    }

    public class EarthQuakeMeasurement : ISubject
    {
        private decimal _seismoMagnitude;
        public decimal SeismoMagnitude {
            get { return _seismoMagnitude; }
            set
            {
                _seismoMagnitude = value;
                Notify();
            }
        }

        private readonly List<IObserver> _observers = new();
        public void Register(IObserver observer)
        {
            _observers.Add(observer);
        }

        public void UnRegister(IObserver observer)
        {
            _observers.Remove(observer);
        }

        public void Notify()
        {
            _observers.ForEach(o => o.Update(this));
        }
    }
}
